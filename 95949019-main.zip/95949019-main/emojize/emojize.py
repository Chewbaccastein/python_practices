import emoji

user_input = input("Input: ")
print(emoji.emojize(user_input, language='alias'))
